import getpass
import calendar
import os
import platform
import sys
#import urllib.request
import re

from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# -------------------------------------------------------------
from pymongo import MongoClient
client = MongoClient('localhost')
db = client.facebookCrawl

#--------------------------------------------------------------
from kafka import KafkaProducer,KafkaConsumer
import json
import time

def kafkaproducer(jsn,topic,brokers = 'localhost:9092'):

	try:
		producer = KafkaProducer(bootstrap_servers=brokers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
		msg = producer.send(topic, jsn)
		resutl = msg.get(timeout=60)
		print(resutl.topic)
		print(resutl.partition)
	except:
		print("Somethings went wrong")
		print("plz Check Kafka connections...")
		time.sleep(10)
		pass


# -------------------------------------------------------------

chromedrive73 ="/root/scraper/fb/fb_crw/chromedrivers/73/chromedriver"
chromedrive74 ="/root/scraper/fb/fb_crw/chromedrivers/74/chromedriver"
chromedrive75 ="/root/scraper/fb/fb_crw/chromedrivers/75/chromedriver"
chromedrive76 ="/root/scraper/fb/fb_crw/chromedrivers/76/chromedriver"



def removeStr(t):
    regex = re.compile(r'[\n]')
    t = regex.sub(' ',t)
    t = t.rstrip()
    return t

# Global Variables

driver = None



# whether to download photos or not
download_uploaded_photos = True
download_friends_photos = True

# whether to download the full image or its thumbnail (small size)
# if small size is True then it will be very quick else if its false then it will open each photo to download it
# and it will take much more time
friends_small_size = True
photos_small_size = True

total_scrolls = 5000
current_scrolls = 0
scroll_time = 5

old_height = 0


# -------------------------------------------------------------
# -------------------------------------------------------------

def get_facebook_images_url(img_links):
    urls = []

    for link in img_links:

        if link != "None":
            valid_url_found = False
            driver.get(link)

            try:
                while not valid_url_found:
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "spotlight")))
                    element = driver.find_element_by_class_name("spotlight")
                    img_url = element.get_attribute('src')

                    if img_url.find('.gif') == -1:
                        valid_url_found = True
                        urls.append(img_url)

            except EC.StaleElementReferenceException:
                urls.append(driver.find_element_by_class_name("spotlight").get_attribute('src'))

            except:
                print("Exception (facebook_image_downloader):", sys.exc_info()[0])
                pass

        else:
            urls.append("None")

    return urls


# -------------------------------------------------------------
# -------------------------------------------------------------

# takes a url and downloads image from that url
def image_downloader(img_links, folder_name,results):
    img_names = []

    try:
        # parent = os.getcwd()
        # try:
        #     folder = os.path.join(os.getcwd(), folder_name)
        #     if not os.path.exists(folder):
        #         os.mkdir(folder)
        #
        #     os.chdir(folder)
        # except:
        #     print("Error in changing directory")

        i = 0
        for link in img_links:
            #img_name = "None"
            img_name = str(results[i])

            # if link != "None":
            #     img_name = (link.split('.jpg')[0]).split('/')[-1] + '.jpg'
            #
            #     if img_name == "10354686_10150004552801856_220367501106153455_n.jpg":
            #         img_name = "None"
            #     else:
            try:
                img_name = img_name.split('/')[-1]
                img_name = str(img_name) + '.jpg'
                # urllib.request.urlretrieve(link, img_name)
                #x = urllib.request.urlretrieve(link, img_name)
                #imgData = {"username":img_name,"imageLink":link}
                #print("image data")
                #print(imgData)
                #insert in database
                #i = db.facebook_profile_pictures.insert_one(imgData)
                # mongoDB

            except:
                img_name = "None"

            img_names.append(img_name)
            i = i + 1

        # os.chdir(parent)
    except:
        print("Exception (image_downloader):", sys.exc_info()[0])

    return img_names


# -------------------------------------------------------------
# -------------------------------------------------------------

def check_height():
    new_height = driver.execute_script("return document.body.scrollHeight")
    return new_height != old_height


# -------------------------------------------------------------
# -------------------------------------------------------------

# helper function: used to scroll the page
def scroll():
    global old_height
    current_scrolls = 0

    while (True):
        try:
            if current_scrolls == total_scrolls:
                return

            old_height = driver.execute_script("return document.body.scrollHeight")
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            WebDriverWait(driver, scroll_time, 0.05).until(lambda driver: check_height())
            current_scrolls += 1
        except TimeoutException:
            break

    return


# -------------------------------------------------------------
# -------------------------------------------------------------

#joda kardan kalamat
def seeMoreRem(query):
    stopwords = ['see', 'more', 'See', 'More', 'See more', 'See More']
    querywords = query.split()

    resultwords = [word for word in querywords if word.lower() not in stopwords]
    result = ' '.join(resultwords)

    return result

# --Helper Functions for Posts

def get_status(x):
    status = ""
    o = x
    link = ""

    try:

        temp = x.find_element_by_xpath(".//div[@class='_5wj-']")
        status = temp.text

        #status = x.find_element_by_xpath(".//div[@class='_5wj-']").text
        try:
            status = status + temp.find_element_by_xpath(".//span[@class='text_exposed_show']").get_attribute(
                'textContent')

            status = seeMoreRem(status)


            linkes = o
            deep = linkes.find_element_by_xpath(".//div[@class='text_exposed_root']")
            deepLinks = deep.find_elements_by_tag_name("a")

            # gereftan link post ha
            results = [p.get_attribute('href') for p in deepLinks]
            results = [create_original_link(x) for x in results]

            link = results
            # tasfieh kardan link az Hastag!
            #main_links = [line for line in results if '/arta.moaser.9/posts/' in line]
            #
            # try:
            #     link = results[0]
            # except:
            #     link = ""
            #     pass


        except:
            pass


    except:
        try:
            status = x.find_element_by_xpath(".//div[@class='userContent']").text
        except:
            pass



    return status,link


def get_div_links(x, tag):
    try:
        temp = x.find_element_by_xpath(".//div[@class='_3x-2']")
        return temp.find_element_by_tag_name(tag)
    except:
        return ""


def get_title_links(title):
    l = title.find_elements_by_tag_name('a')
    return l[-1].text, l[-1].get_attribute('href')


def get_title(x):
    title = ""
    try:
        title = x.find_element_by_xpath(".//span[@class='fwb fcg']")
    except:
        try:
            title = x.find_element_by_xpath(".//span[@class='fcg']")
        except:
            try:
                title = x.find_element_by_xpath(".//span[@class='fwn fcg']")
            except:
                pass
    finally:
        return title


def get_time(x):
    time = ""
    try:
        time = x.find_element_by_tag_name('abbr').get_attribute('title')
        time = str("%02d" % int(time.split(", ")[1].split()[1]), ) + "-" + str(
            ("%02d" % (int((list(calendar.month_abbr).index(time.split(", ")[1].split()[0][:3]))),))) + "-" + \
               time.split()[3] + " " + str("%02d" % int(time.split()[5].split(":")[0])) + ":" + str(
            time.split()[5].split(":")[1])
    except:
        pass

    finally:
        return time


def extract_and_write_posts(elements, filename,username):
    try:
        #f = open(filename, "w", newline='\r\n')
        #f.writelines(' TIME || TYPE  || TITLE || STATUS  ||   LINKS(Shared Posts/Shared Links etc) ' + '\n' + '\n')

        for x in elements:
            try:
                video_link = " "
                title = " "
                status = " "
                link = ""
                img = " "
                time = " "

                # time
                time = get_time(x)

                # title
                title = get_title(x)
                if title.text.find("shared a memory") != -1:
                    x = x.find_element_by_xpath(".//div[@class='_1dwg _1w_m']")
                    title = get_title(x)

                status,PostLink = get_status(x)
                if title.text == driver.find_element_by_id("fb-timeline-cover-name").text:
                    if status == '':
                        temp = get_div_links(x, "img")
                        if temp == '':  # no image tag which means . it is not a life event
                            link = get_div_links(x, "a").get_attribute('href')
                            type = "status update without text"
                        else:
                            type = 'life event'
                            link = get_div_links(x, "a").get_attribute('href')
                            status = get_div_links(x, "a").text
                    else:
                        type = "status update"
                        if get_div_links(x, "a") != '':
                            link = get_div_links(x, "a").get_attribute('href')

                elif title.text.find(" shared ") != -1:

                    x1, link = get_title_links(title)
                    type = "shared " + x1

                elif title.text.find(" at ") != -1 or title.text.find(" in ") != -1:
                    if title.text.find(" at ") != -1:
                        x1, link = get_title_links(title)
                        type = "check in"
                    elif title.text.find(" in ") != 1:
                        status = get_div_links(x, "a").text

                elif title.text.find(" added ") != -1 and title.text.find("photo") != -1:
                    type = "added photo"
                    link = get_div_links(x, "a").get_attribute('href')

                elif title.text.find(" added ") != -1 and title.text.find("video") != -1:
                    type = "added video"
                    link = get_div_links(x, "a").get_attribute('href')

                else:
                    type = "others"

                if not isinstance(title, str):
                    title = title.text

                status = status.replace("\n", " ")
                title = title.replace("\n", " ")

                try:
                    data_status = {"username":username,"time":time,"type":type,"title":str(title),"status":str(status),"link":link,"Post Link:":PostLink}
                    kafkaproducer({"collections":"profile_scrap","data":data_status},topic="facebook_bot_01")
                    i = db.profile_scrap.insert_one(data_status)
                    #f.writelines(line)
                except:
                    print('Posts: Could not map encoded characters')
            except:
                pass
        #f.close()
    except:
        print("Exception (extract_and_write_posts)", "Status =", sys.exc_info()[0])

    return


# -------------------------------------------------------------
# -------------------------------------------------------------


def save_to_file(name, elements, status, current_section,username):
    """helper function used to save links to files"""
    profile_id = []
    # status 0 = dealing with friends list
    # status 1 = dealing with photos
    # status 2 = dealing with videos
    # status 3 = dealing with about section
    # status 4 = dealing with posts

    try:

        f = None  # file pointer

        if status != 4:
            pass
            #f = open(name, 'w', encoding='utf-8', newline='\r\n')

        results = []
        img_names = []

        # dealing with Friends
        if status == 0:

            results = [x.get_attribute('href') for x in elements]
            results = [create_original_link(x) for x in results]

            try:
                for i in results:
                    data={{"profile_id": i, "crawlStatus": False}}
                    kafkaproducer({"collections":"profile_list","data":data},topic="facebook_bot_01")
                    i2 = db.profile_list.insert_one(data)
                    profile_id.append(i.split('/')[-1])

            except:
                print("error")
                pass

            data = {"username":username,"friends":profile_id}
            kafkaproducer({"collections": "facebook_friends", "data": data}, topic="facebook_bot_01")
            i = db.facebook_friends.insert_one(data)




            #mongodb

            try:
                if download_friends_photos:

                    if friends_small_size:
                        img_links = [x.find_element_by_css_selector('img').get_attribute('src') for x in elements]
                    else:
                        links = []
                        for friend in results:
                            driver.get(friend)
                            WebDriverWait(driver, 10).until(
                                EC.presence_of_element_located((By.CLASS_NAME, "profilePicThumb")))
                            l = driver.find_element_by_class_name("profilePicThumb").get_attribute('href')
                            links.append(l)

                        for i in range(len(links)):
                            if links[i].find('picture/view') != -1:
                                links[i] = "None"
                        img_links = get_facebook_images_url(links)


                    folder_names = ["Friend's Photos", "Following's Photos", "Follower's Photos", "Work Friends Photos",
                                    "College Friends Photos", "Current City Friends Photos", "Hometown Friends Photos"]
                    #print("Downloading " + folder_names[current_section])

                    #print(img_links)
                    data = {"img_links":img_links,"Sections":folder_names[current_section],"results":results}
                    kafkaproducer({"collections": "facebook_img_links", "data": data}, topic="facebook_bot_01")
                    #img_names = image_downloader(img_links, folder_names[current_section],results)
            except:
                print("Exception (Images)", str(status), "Status =", current_section, sys.exc_info()[0])

        # dealing with Photos
        elif status == 1:
            results = [x.get_attribute('href') for x in elements]
            results.pop(0)

            try:
                if download_uploaded_photos:
                    if photos_small_size:
                        background_img_links = driver.find_elements_by_xpath("//*[contains(@id, 'pic_')]/div/i")
                        background_img_links = [x.get_attribute('style') for x in background_img_links]
                        background_img_links = [((x.split('(')[1]).split(')')[0]).strip('"') for x in
                                                background_img_links]
                    else:
                        background_img_links = get_facebook_images_url(results)

                    folder_names = ["Uploaded Photos", "Tagged Photos"]
                    print("Downloading " + folder_names[current_section])


                    data = {"background_img_links": background_img_links, "file name": folder_names[current_section]}
                    kafkaproducer({"collections": "facebook_img_links", "data": data}, topic="facebook_bot_01")
                    #img_names = image_downloader(background_img_links, folder_names[current_section])

            except:
                print("Exception (Images)", str(status), "Status =", current_section, sys.exc_info()[0])

        # dealing with Videos
        elif status == 2:
            results = elements[0].find_elements_by_css_selector('li')
            results = [x.find_element_by_css_selector('a').get_attribute('href') for x in results]

            try:
                if results[0][0] == '/':
                    results = [r.pop(0) for r in results]
                    #results = [("https://en-gb.facebook.com/" + x) for x in results]
                    print("result-inja")
                    print(results)
            except:
                pass

        # dealing with About Section
        elif status == 3:
            results = elements[0].text
            results = removeStr(results)
            type = re.findall('([A-Z]+(?:(?!\s?[A-Z][a-z])\s?[A-Z])+)', results)


            if "Birthday" in results:
                before_keyword, keyword, after_keyword = results.partition("Birthday")
                Birthday = {"username:":username,"Birthday":after_keyword}
                kafkaproducer({"collections": "profile_scrap", "data": Birthday}, topic="facebook_bot_01")
                i = db.profile_scrap.insert_one(Birthday)

            if "Phones" in results:
                unique_word_a = 'Phones'
                unique_word_b = 'Birthday'
                s = results
                phoneNumber = s[s.find(unique_word_a) + len(unique_word_a):s.find(unique_word_b)].strip()
                Phones = {"username:":username,"Phones":phoneNumber}
                kafkaproducer({"collections": "profile_scrap", "data": Phones}, topic="facebook_bot_01")
                i = db.profile_scrap.insert_one(Phones)


            if type == []:
                if "workplace" in results:
                    type = ['workplace','school/university','current city',"..."]

            data = {"username:":username,"Abouts": type,"data":results}
            kafkaproducer({"collections": "profile_scrap", "data": data}, topic="facebook_bot_01")
            i = db.profile_scrap.insert_one(data)


        # dealing with Posts
        elif status == 4:
            extract_and_write_posts(elements, name,username)
            return

        # if (status == 0) or (status == 1):
        #     for i in range(len(results)):
        #         f.writelines(results[i])
        #         f.write(',')
        #         try:
        #             f.writelines(img_names[i])
        #         except:
        #             f.writelines("None")
        #         f.write('\n')
        #
        # elif status == 2:
        #     for x in results:
        #         f.writelines(x + "\n")
        #
        # f.close()

    except:
        print("Exception (save_to_file)", "Status =", str(status), sys.exc_info()[0])

    return


# ----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def scrap_data(id, scan_list, section, elements_path, save_status, file_names):
    """Given some parameters, this function can scrap friends/photos/videos/about/posts(statuses) of a profile"""
    username = id.split('/')[-1]
    page = []

    if save_status == 4:
        page.append(id)

    for i in range(len(section)):
        page.append(id + section[i])
    for i in range(len(scan_list)):

        try:
            driver.get(page[i])

            if (save_status == 0) or (save_status == 1) or (
                    save_status == 2):  # Only run this for friends, photos and videos

                # the bar which contains all the sections
                sections_bar = driver.find_element_by_xpath("//*[@class='_3cz'][1]/div[2]/div[1]")

                if sections_bar.text.find(scan_list[i]) == -1:
                    continue

            if save_status != 3:
                scroll()


            data = driver.find_elements_by_xpath(elements_path[i])


            save_to_file(file_names[i], data, save_status, i,username)

        except:
            print("Exception (scrap_data)", str(i), "Status =", str(save_status), sys.exc_info()[0])


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def create_original_link(url):
    if url.find(".php") != -1:
        original_link = "https://en-gb.facebook.com/" + ((url.split("="))[1])

        if original_link.find("&") != -1:
            original_link = original_link.split("&")[0]

    elif url.find("fnr_t") != -1:
        original_link = "https://en-gb.facebook.com/" + ((url.split("/"))[-1].split("?")[0])
    elif url.find("_tab") != -1:
        original_link = "https://en-gb.facebook.com/" + (url.split("?")[0]).split("/")[-1]
    else:
        original_link = url

    return original_link


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def scrap_profile(ids):


    # folder = os.path.join(os.getcwd(), "Data")
    #
    # if not os.path.exists(folder):
    #     os.mkdir(folder)
    #
    # os.chdir(folder)

    # execute for all profiles given in input.txt file
    for id in ids:

        driver.get(id)
        url = driver.current_url
        id = create_original_link(url)

        print("\nScraping:", id)

        # try:
        #     if not os.path.exists(os.path.join(folder, id.split('/')[-1])):
        #         os.mkdir(os.path.join(folder, id.split('/')[-1]))
        #     else:
        #         print("A folder with the same profile name already exists."
        #               " Kindly remove that folder first and then run this code.")
        #         continue
        #     os.chdir(os.path.join(folder, id.split('/')[-1]))
        # except:
        #     print("Some error occurred in creating the profile directory.")
        #     continue

        # ----------------------------------------------------------------------------
        print("----------------------------------------")
        print("Friends..")
        # setting parameters for scrap_data() to scrap friends
        scan_list = ["All", "Following", "Followers", "Work", "College", "Current City", "Hometown"]
        section = ["/friends", "/following", "/followers", "/friends_work", "/friends_college", "/friends_current_city",
                   "/friends_hometown"]
        elements_path = ["//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                         "//*[contains(@class,'_3i9')][1]/div/div/ul/li[1]/div[2]/div/div/div/div/div[2]/ul/li/div/a",
                         "//*[contains(@class,'fbProfileBrowserListItem')]/div/a",
                         "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                         "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                         "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a",
                         "//*[contains(@id,'pagelet_timeline_medley_friends')][1]/div[2]/div/ul/li/div/a"]
        file_names = ["All Friends.txt", "Following.txt", "Followers.txt", "Work Friends.txt", "College Friends.txt",
                      "Current City Friends.txt", "Hometown Friends.txt"]
        save_status = 0

        scrap_data(id, scan_list, section, elements_path, save_status, file_names)
        print("Friends Done")
        # # ----------------------------------------------------------------------------
        #
        print("----------------------------------------")
        print("Photos..")
        print("Scraping Links..")
        # setting parameters for scrap_data() to scrap photos
        scan_list = ["'s Photos", "Photos of"]
        section = ["/photos_all", "/photos_of"]
        elements_path = ["//*[contains(@id, 'pic_')]"] * 2
        file_names = ["Uploaded Photos.txt", "Tagged Photos.txt"]
        save_status = 1

        scrap_data(id, scan_list, section, elements_path, save_status, file_names)
        print("Photos Done")
        #
        # # ----------------------------------------------------------------------------
        #
        # print("----------------------------------------")
        # print("Videos:")
        # # setting parameters for scrap_data() to scrap videos
        # scan_list = ["'s Videos", "Videos of"]
        # section = ["/videos_by", "/videos_of"]
        # elements_path = ["//*[contains(@id, 'pagelet_timeline_app_collection_')]/ul"] * 2
        # file_names = ["Uploaded Videos.txt", "Tagged Videos.txt"]
        # save_status = 2
        #
        # scrap_data(id, scan_list, section, elements_path, save_status, file_names)
        # print("Videos Done")
        # ----------------------------------------------------------------------------

        print("----------------------------------------")
        print("About:")
        # setting parameters for scrap_data() to scrap the about section
        scan_list = [None] * 7
        section = ["/about?section=overview", "/about?section=education", "/about?section=living",
                    "/about?section=contact-info", "/about?section=relationship", "/about?section=bio",
                    "/about?section=year-overviews"]
        elements_path = ["//*[contains(@id, 'pagelet_timeline_app_collection_')]/ul/li/div/div[2]/div/div"] * 7
        file_names = ["Overview.txt", "Work and Education.txt", "Places Lived.txt", "Contact and Basic Info.txt",
                       "Family and Relationships.txt", "Details About.txt", "Life Events.txt"]
        save_status = 3

        scrap_data(id, scan_list, section, elements_path, save_status, file_names)
        print("About Section Done")

        # ----------------------------------------------------------------------------
        print("----------------------------------------")
        print("Posts:")
        # setting parameters for scrap_data() to scrap posts
        scan_list = [None]
        section = []
        elements_path = ['//div[@class="_5pcb _4b0l _2q8l"]']
        file_names = ["Posts.txt"]
        save_status = 4
        scrap_data(id, scan_list, section, elements_path, save_status, file_names)
        print("Posts(Statuses) Done")
        print("----------------------------------------")
    # ----------------------------------------------------------------------------


    return


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def login(email, password):
    """ Logging into our own profile """

    try:
        global driver

        options = Options()

        #  Code to disable notifications pop up of Chrome Browser
        options.add_argument("--disable-notifications")
        options.add_argument("--disable-infobars")
        options.add_argument("--mute-audio")
        options.add_argument("--headless")

        i = False
        #
        # try:
        #     if i == False:
        #         print ("try chrome driver 73")
        #         print (chromedrive73)
        #         #driver = webdriver.Chrome(driver_path=chromedrive73,
        #          #                         service_args=['--verbose', '--log-path=/tmp/chromedriver.log'])
        #
        #         driver = webdriver.chrome(executable_path=chromedrive73,options=options)
        #         os.environ["webdriver.chrome.driver"] = chromedrive73
        #         i = True
        # except:
        #     print ("chrome driver 73 was False")
        #     i = False
        #
        # try:
        #     if i == False:
        #         print ("try chrome driver 74")
        #         print (chromedrive74)
        #         #driver = webdriver.Chrome(driver_path=chromedrive74,
        #          #                         service_args=['--verbose', '--log-path=/tmp/chromedriver.log'])
        #
        #         driver = webdriver.chrome(executable_path=chromedrive74,options=options)
        #         os.environ["webdriver.chrome.driver"] = chromedrive74
        #         i = True
        # except:
        #     print ("chrome driver 74 was False")
        #     i = False
        #
        # try:
        #     if i == False:
        #         print ("try chrome driver 75")
        #         print (chromedrive75)
        #         #driver = webdriver.Chrome(driver_path=chromedrive75,
        #          #                         service_args=['--verbose', '--log-path=/tmp/chromedriver.log'])
        #
        #         driver = webdriver.chrome(executable_path=chromedrive75,options=options)
        #         os.environ["webdriver.chrome.driver"] = chromedrive75
        #         i = True
        # except:
        #     print ("chrome driver 75 was False")
        #     i = False
        #
        # try:
        #     if i == False:
        #         print ("try chrome driver 76")
        #         print (chromedrive76)
        #         #driver = webdriver.Chrome(driver_path=chromedrive76,
        #         #                          service_args=['--verbose', '--log-path=/tmp/chromedriver.log'])
        #
        #         driver = webdriver.chrome(executable_path=chromedrive76,options=options)
        #         os.environ["webdriver.chrome.driver"] = chromedrive76
        #         i = True
        # except:
        #     print ("chrome driver 76 was False")
        #     i = False
        #
        #
        # try:
        #     if i == False:
        #         print("try  driver firefox")
        #         driver = webdriver.firefox(executable_path="/root//root/scraper/fb/fb_crw/firfoxwebdrive/geckodriver")
        #         os.environ["webdriver.firefox.driver"] = "/root//root/scraper/fb/fb_crw/firfoxwebdrive/geckodriver"
        #         i = True
        # except:
        #     print("firefox drive was False")
        #     i = False




        #
        # display = Display(visible=0, size=(800, 600))
        # display.start()
        #
        # print (i)


        try:
            platform_ = platform.system().lower()
            if platform_ in ['linux', 'darwin']:
                driver = webdriver.Chrome(executable_path="/Users/vahid/Downloads/chromedriver", options=options)
            else:
                driver = webdriver.Chrome(executable_path="./chromedriver.exe", options=options)
        except:
            print("Kindly replace the Chrome Web Driver with the latest one from"
                  "http://chromedriver.chromium.org/downloads"
                  "\nYour OS: {}".format(platform_)
                 )
            exit()


        driver.get("https://en-gb.facebook.com")
        driver.maximize_window()

        # filling the form
        print ("Start login user as %s" % email)
        driver.find_element_by_name('email').send_keys(email)
        driver.find_element_by_name('pass').send_keys(password)

        # clicking on login button
        driver.find_element_by_id('loginbutton').click()

    except Exception as e:
        print("There's some error in log in.")
        print(sys.exc_info()[0])
        exit()


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------

def main():
    id_list =[]
    # ids = ["https://en-gb.facebook.com/" + line.split("/")[-1] for line in open("input.txt", newline='\n')]
    # print(ids)

    email ="989128439547"
    password ="DaryaMajd"
    #email = "aryanmn1992@gmail.com"
    #password = "AryanTanha1991"
    login(email, password)


    ids_db_c = db.profile_list.find({"crawlStatus":False}).count()

    if ids_db_c > 0:
        ids_db = db.profile_list.find({"crawlStatus": False})
        for i in ids_db:
            ids = i["profile_id"]
            ids = ids.split("/")[-1]
            print("\nStarting Scraping %s" % ids)
            id_list.append(i["profile_id"])
            scrap_profile(id_list)
            update = db.profile_list.update({"profile_id": i["profile_id"]}, {"$set": {"crawlStatus": True}})
            print("\nProcess Completed.")
            id_list = []

    else:
        ids = ["https://en-gb.facebook.com/" + line.split("/")[-1] for line in open("input.txt", newline='\n')]
        print("\nStarting Scraping %s" % ids)
        scrap_profile(ids)
        data = {"profile_id": ids, "crawlStatus": True}
        kafkaproducer({"collections":"profile_list","data":data})
        i = db.profile_list.insert_one({"profile_id": ids,"crawlStatus": True})



    driver.close()


        # if len(ids) > 0:
        #     # Getting email and password from user to login into his/her profile
        #     # email = input('\nEnter your Facebook Email: ')
        #     # password = getpass.getpass()


        # else:
        #     print("Input file is empty..")



# -------------------------------------------------------------
# -------------------------------------------------------------
# -------------------------------------------------------------

if __name__ == '__main__':
    # get things rolling
    main()





