from kafka import KafkaProducer,KafkaConsumer
import json
import time



def kafkaproducer(jsn,topic,brokers = 'localhost:9092'):

	try:
		producer = KafkaProducer(bootstrap_servers=brokers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
		msg = producer.send(topic,jsn)
		resutl = msg.get(timeout=60)
		print(resutl.topic)
		print(resutl.partition)
	except:
		print("Somethings went wrong")
		print("plz Check Kafka connections...")
		time.sleep(10)
		pass


def kafkaCunsumer(topic,group_id,brokers = None):

	if brokers == None:
		if group_id == None:
			consumer = KafkaConsumer(topic=topic)
		else:
			consumer = KafkaConsumer(topic=topic, group_id=group_id)

	else:
		if group_id == None:
			consumer = KafkaConsumer(topic=topic, bootstrap_servers=brokers)

		else:
			consumer = KafkaConsumer(topic=topic, group_id=group_id, bootstrap_servers=brokers)

