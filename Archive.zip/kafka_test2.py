from kafka import KafkaProducer,KafkaConsumer
import json
import time

from pymongo import MongoClient
client = MongoClient('localhost')
db = client.facebookCrawl

def kafkaproducer(jsn,topic,brokers = 'localhost:9092'):
    producer = KafkaProducer(bootstrap_servers=brokers,value_serializer=lambda v: json.dumps(v).encode('utf-8'))
    msg = producer.send(topic,jsn)
    resutl = msg.get(timeout=60)
    print(resutl.topic)
    print(resutl.partition)

def kafkaCunsumer(topic,group_id=None,brokers = None):

	try:
		if brokers == None:
			if group_id == None:
				consumer = KafkaConsumer(topic, auto_offset_reset='earliest',
				                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))
			else:
				consumer = KafkaConsumer(topic, group_id=group_id, auto_offset_reset='earliest',
				                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))

		else:
			if group_id == None:
				consumer = KafkaConsumer(topic, bootstrap_servers=brokers, auto_offset_reset='earliest',
				                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))


			else:
				consumer = KafkaConsumer(topic, group_id=group_id, bootstrap_servers=brokers,
				                         auto_offset_reset='earliest',
				                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))

		consumer.subscribe(topic)

		for msg in consumer:
			print(msg.value)
			collections = msg.value["collections"]
			data = msg.value["data"]
			i = db[collections].insert(data)

		consumer.commit()

	except:
		print("Somethings went wrong")
		print("plz Check Kafka connections...")
		time.sleep(10)
		pass


results = kafkaCunsumer(topic="facebook_bot_01",brokers= 'localhost:9092')

