from datetime import timedelta
from tkinter import dialog
import datetime
import time
import dateutil.parser
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv
import socks
import re

#-------------MongoDB Config-------------#
from pymongo import MongoClient
client = MongoClient('localhost')
db = client.telegram
#--------------*****----------------------#


#-------------Kafka Config----------------#

from kafka import KafkaProducer,KafkaConsumer
import json

def kafkaproducer(jsn,topic,brokers = 'localhost:9092'):

	try:
		producer = KafkaProducer(bootstrap_servers=brokers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
		msg = producer.send(topic, jsn)
		resutl = msg.get(timeout=60)
		print(resutl.topic)
		print(resutl.partition)
	except:
		print("Somethings went wrong")
		print("plz Check Kafka connections...")
		time.sleep(10)
		pass

#--------------*****----------------------#


#estekhraj username_channels_groups
def extract_username(url):
    return re.search(r'https://t.me/([^/?]+)', url).group(1)

#estekhraj username_private_groups
def extract_pvgb_username(url):
    return re.search(r'https://t.me/joinchat/([^/?]+)', url).group(1)


#proxy = (socks.SOCKS5, '127.0.0.1', 9150)


api_id = 796906
api_hash = '80a4ef01149c6c639b815cafbd3aab49'
phone = '+989192683701'
client = TelegramClient(phone, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone)
    client.sign_in(phone, input('Enter the code: '))

chats = []
last_date = None
chunk_size = 10000000
groups = []
channel = []




# ====================================گروه تلگرام==================
from telethon import errors
def telegramGroupExtract(groupURL=None,search=None):


    if groupURL !=None:
        g = ''
        if extract_username(groupURL) == "joinchat":
            username = extract_pvgb_username(url=groupURL)
        else:
            username = extract_username(url=groupURL)
        try:
            updates = client(ImportChatInviteRequest(username))
            g = client.get_entity(groupURL)

        except Exception as e:
            print(e)
            g = client.get_entity(groupURL)
            pass


        try:
            members = []

            print("group < %s > crawl start..." % g.title)

            findc = db.groups_info.find({"group_id": int(g.id)}).count()

            if findc == 0:
                print("strat fetching group < %s > " % g.title)

                try:
                    if g.id:
                        group_id = g.id
                    else:
                        group_id = ''

                    if g.username:
                        group_username = g.username
                    else:
                        group_username = ''

                    if g.title:
                        group_title = g.title

                    else:
                        group_title = ''

                    if g.date:
                        group_create_date = g.date

                    else:
                        group_create_date = ''

                    if g.access_hash:
                        group_access_hash = g.access_hash

                    else:
                        group_access_hash = ''

                    try:
                        print('Fetching Members...')
                        all_participants = []
                        all_participants = client.get_participants(g, aggressive=True)

                        for user in all_participants:
                            if user.username:
                                username = user.username
                            else:
                                username = ""
                            if user.id:
                                user_id = user.id
                            else:
                                user_id = ""
                            if user.phone:
                                phone_number = user.phone
                            else:
                                phone_number = ""
                            if user.first_name:
                                first_name = user.first_name
                            else:
                                first_name = ""
                            if user.last_name:
                                last_name = user.last_name
                            else:
                                last_name = ""

                            data_mem = {"group_name": g.title, "group_id": g.id, "username": username,
                                        "user_id": user_id, "first_name": first_name,
                                        "last_name": last_name,
                                        "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                            try:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections":"telegram_group_people","data":data_mem},topic="telegram_bot")

                            except:
                                print("somethings wrong in mongo connection-telegram_people")

                            members.append(data_mem)

                    except:
                        print("somthings wrong in feteching members")
                        members = []
                        pass

                    now = datetime.datetime.now()
                    data = {"group_id": int(group_id), "group_username": group_username, "group_title": group_title,
                            "group_create_date": group_create_date, "group_access_hash": group_access_hash,
                            "is_crawl": False,
                            "members": members,
                            "fetch_date": now}
                    print("< %s > Informations: " % group_username)
                    print(data)

                    try:
                        insert = db.groups_info.insert_one(data)
                        kafkaproducer({"collections": "groups_info", "data": data}, topic="telegram_bot")

                        print('Saving In Database...')
                        print('Members scraped successfully.')
                    except:
                        print("somethings wrong in mongo connection-group_info")

                    print("Start fetching last messages...")
                    messages = client.get_messages(g,search=search)

                    for message in messages:

                        if message.message:
                            message_txt = message.message
                        else:
                            message_txt = ""

                        if message.from_id:
                            user_id = message.from_id
                        else:
                            user_id = ""

                        if message.reply_to_msg_id:
                            reply_to_id = message.reply_to_msg_id

                        else:
                            reply_to_id = ""

                        if message.fwd_from:
                            froward_from = message.fwd_from
                        else:
                            froward_from = ""

                        if message.date:
                            date = message.date
                        else:
                            date = ""

                        data_group = {"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                        try:
                            insert = db.groups_message_info.insert_one(data_group)
                            kafkaproducer({"collections": "groups_message_info", "data": data_group}, topic="telegram_bot")
                            time.sleep(1)

                        except:
                            print("somethings wrong in mongo connection-groups_message_info")

                        print("Messages fetched successfully")


                except:
                    print("somethings wrong in fetching groups...")
                    pass

            # agar ghablan crawl shoede bud
            if findc > 0:
                print("group %s is there." % g.title)

                savedMembers = []
                find_mem = db.telegram_group_people.find({"group_name": g.title})
                for i in find_mem:
                    savedMembers.append(int(i["user_id"]))

                try:
                    print('Fetching Members new members...')
                    all_participants = []
                    all_participants = client.get_participants(g, aggressive=True)

                    for user in all_participants:
                        if user.username:
                            username = user.username
                        else:
                            username = ""
                        if user.id:
                            user_id = int(user.id)
                        else:
                            user_id = ""
                        if user.phone:
                            phone_number = user.phone
                        else:
                            phone_number = ""
                        if user.first_name:
                            first_name = user.first_name
                        else:
                            first_name = ""
                        if user.last_name:
                            last_name = user.last_name
                        else:
                            last_name = ""

                        data_mem = {"group_name": g.title, "group_id": g.id, "username": username, "user_id": user_id,
                                    "first_name": first_name, "last_name": last_name,
                                    "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                        try:
                            if user_id not in savedMembers:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                              topic="telegram_bot")

                                print("member %s saving in db." % username)

                            else:
                                print("member %s was saved in db." % username)

                        except:
                            print("somethings wrong in mongo connection-telegram_people")

                        members.append(data_mem)

                except:
                    print("somthings wrong in feteching members")
                    members = []
                    pass

                x = db.groups_message_info.find({"group_name": g.title}).limit(1).sort("$natural", 1)

                for d in x:
                    last_d = d["date"]

                print("Start fetching new 1000 messages...")
                messages = client.get_messages(g, 1000,search=search)

                for message in messages:

                    if message.message:
                        message_txt = message.message
                    else:
                        message_txt = ""

                    if message.from_id:
                        user_id = message.from_id
                    else:
                        user_id = ""

                    if message.reply_to_msg_id:
                        reply_to_id = message.reply_to_msg_id

                    else:
                        reply_to_id = ""

                    if message.fwd_from:
                        froward_from = message.fwd_from
                    else:
                        froward_from = ""

                    if message.date:
                        date = message.date
                    else:
                        date = ""

                    data_group_now = {"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                    try:

                        if date.year == last_d.year:

                            if date.month == last_d.month:

                                if date.day == last_d.day:

                                    if date.hour > last_d.hour:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")

                                else:
                                    if date.day > last_d.day:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")
                            else:
                                if date.month > last_d.month:
                                    insert = db.groups_message_info.insert_one(data_group_now)
                                    kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                  topic="telegram_bot")
                        else:
                            if date.year > last_d.year:
                                insert = db.groups_message_info.insert_one(data_group_now)
                                kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                              topic="telegram_bot")

                    except:
                        print("somethings wrong in mongo connection-groups_message_info")

                print("Last new messages fetched...")


        except:
            print("somethings was wrong...")

    if groupURL == None:
        result = client(GetDialogsRequest(
            offset_date=last_date,
            offset_id=0,
            offset_peer=InputPeerEmpty(),
            limit=chunk_size,
            hash=0
        ))

        chats.extend(result.chats)
        # chats.extend(result.channels)

        for chat in chats:
            try:
                if chat.megagroup == True:
                    groups.append(chat)
            except:
                continue

        for g in groups:
            members = []

            print("group %s crawl start..." % g.title)

            findc = db.groups_info.find({"group_id": int(g.id)}).count()

            if findc == 0:
                print("strat fetching group %s " % g.title)

                try:
                    if g.id:
                        group_id = g.id
                    else:
                        group_id = ''

                    if g.username:
                        group_username = g.username
                    else:
                        group_username = ''

                    if g.title:
                        group_title = g.title

                    else:
                        group_title = ''

                    if g.date:
                        group_create_date = g.date

                    else:
                        group_create_date = ''

                    if g.access_hash:
                        group_access_hash = g.access_hash

                    else:
                        group_access_hash = ''

                    try:
                        print('Fetching Members...')
                        all_participants = []
                        all_participants = client.get_participants(g, aggressive=True)

                        for user in all_participants:
                            if user.username:
                                username = user.username
                            else:
                                username = ""
                            if user.id:
                                user_id = user.id
                            else:
                                user_id = ""
                            if user.phone:
                                phone_number = user.phone
                            else:
                                phone_number = ""
                            if user.first_name:
                                first_name = user.first_name
                            else:
                                first_name = ""
                            if user.last_name:
                                last_name = user.last_name
                            else:
                                last_name = ""

                            data_mem = {"group_name": g.title, "group_id": g.id, "username": username,
                                        "user_id": user_id, "first_name": first_name,
                                        "last_name": last_name,
                                        "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                            try:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                              topic="telegram_bot")

                            except:
                                print("somethings wrong in mongo connection-telegram_people")

                            members.append(data_mem)

                    except:
                        print("somthings wrong in feteching members")
                        members = []
                        pass

                    now = datetime.datetime.now()
                    data = {"group_id": int(group_id), "group_username": group_username, "group_title": group_title,
                            "group_create_date": group_create_date, "group_access_hash": group_access_hash,
                            "is_crawl": False,
                            "members": members,
                            "fetch_date": now}
                    print(data)

                    try:
                        insert = db.groups_info.insert_one(data)
                        kafkaproducer({"collections": "groups_info", "data": data},
                                      topic="telegram_bot")
                        print('Saving In Database...')
                        print('Members scraped successfully.')
                    except:
                        print("somethings wrong in mongo connection-group_info")

                    print("Start fetching last 1000 messages...")
                    messages = client.get_messages(g, 1000,search=search)

                    for message in messages:

                        if message.message:
                            message_txt = message.message
                        else:
                            message_txt = ""

                        if message.from_id:
                            user_id = message.from_id
                        else:
                            user_id = ""

                        if message.reply_to_msg_id:
                            reply_to_id = message.reply_to_msg_id

                        else:
                            reply_to_id = ""

                        if message.fwd_from:
                            froward_from = message.fwd_from
                        else:
                            froward_from = ""

                        if message.date:
                            date = message.date
                        else:
                            date = ""

                        data_group = {"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                        try:
                            insert = db.groups_message_info.insert_one(data_group)
                            kafkaproducer({"collections": "groups_message_info", "data": data_group},
                                          topic="telegram_bot")


                        except:
                            print("somethings wrong in mongo connection-groups_message_info")

                    print("Messages fetched successfully")


                except:
                    print("somethings wrong in fetching groups...")
                    pass

            # agar ghablan crawl shoede bud
            if findc > 0:
                print("group %s is there." % g.title)

                savedMembers = []
                find_mem = db.telegram_group_people.find({"group_name": g.title})
                for i in find_mem:
                    savedMembers.append(int(i["user_id"]))

                try:
                    print('Fetching Members new members...')
                    all_participants = []
                    all_participants = client.get_participants(g, aggressive=True)

                    for user in all_participants:
                        if user.username:
                            username = user.username
                        else:
                            username = ""
                        if user.id:
                            user_id = int(user.id)
                        else:
                            user_id = ""
                        if user.phone:
                            phone_number = user.phone
                        else:
                            phone_number = ""
                        if user.first_name:
                            first_name = user.first_name
                        else:
                            first_name = ""
                        if user.last_name:
                            last_name = user.last_name
                        else:
                            last_name = ""

                        data_mem = {"group_name": g.title, "group_id": g.id, "username": username, "user_id": user_id,
                                    "first_name": first_name, "last_name": last_name,
                                    "phone_number": phone_number, "is_bot": user.bot, "is_deleted": user.deleted}

                        try:
                            if user_id not in savedMembers:
                                insert_pe = db.telegram_group_people.insert_one(data_mem)
                                kafkaproducer({"collections": "telegram_group_people", "data": data_mem},
                                              topic="telegram_bot")
                                print("member %s saving in db." % username)

                            else:
                                print("member %s was saved in db." % username)

                        except:
                            print("somethings wrong in mongo connection-telegram_people")

                        members.append(data_mem)

                except:
                    print("somthings wrong in feteching members")
                    members = []
                    pass

                x = db.groups_message_info.find({"group_name": g.title}).limit(1).sort("$natural", 1)

                for d in x:
                    last_d = d["date"]

                print("Start fetching new 1000 messages...")
                messages = client.get_messages(g, 1000,search=search)

                for message in messages:

                    if message.message:
                        message_txt = message.message
                    else:
                        message_txt = ""

                    if message.from_id:
                        user_id = message.from_id
                    else:
                        user_id = ""

                    if message.reply_to_msg_id:
                        reply_to_id = message.reply_to_msg_id

                    else:
                        reply_to_id = ""

                    if message.fwd_from:
                        froward_from = message.fwd_from
                    else:
                        froward_from = ""

                    if message.date:
                        date = message.date
                    else:
                        date = ""

                    data_group_now = {"group_name": g.title, "group_id": g.id, "message": message_txt,
                                      "from_user_id": user_id, "reply_to_id": reply_to_id, "froward_from": froward_from,
                                      "date": date}

                    try:

                        if date.year == last_d.year:

                            if date.month == last_d.month:

                                if date.day == last_d.day:

                                    if date.hour > last_d.hour:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")

                                else:
                                    if date.day > last_d.day:
                                        insert = db.groups_message_info.insert_one(data_group_now)
                                        kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                      topic="telegram_bot")
                            else:
                                if date.month > last_d.month:
                                    insert = db.groups_message_info.insert_one(data_group_now)
                                    kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                                  topic="telegram_bot")
                        else:
                            if date.year > last_d.year:
                                insert = db.groups_message_info.insert_one(data_group_now)
                                kafkaproducer({"collections": "groups_message_info", "data": data_group_now},
                                              topic="telegram_bot")

                    except:
                        print("somethings wrong in mongo connection-groups_message_info")

                print("Last new messages fetched...")




def channelExtract(username=None):


    if username == None:


        # get all the channels that I can access
        channels = {d.entity.username: d.entity
                    for d in client.get_dialogs()
                    if d.is_channel}


        for i in channels:

            findc = db.channel_posts.find({"channel_name": i}).count()

            if findc == 0:
                ischannel = False
                messages = client.iter_messages(entity=i, limit=None)
                print("Start fetching messages of channel %s." % i)
                for k in messages:
                    if k.to_id.channel_id:
                        channel_id = k.to_id.channel_id
                    else:
                        channel_id = ''
                    if k.message:
                        message = k.message
                    else:
                        message = ""

                    if k.date:
                        date = k.date
                    else:
                        date = ''

                    if k.views:
                        views = k.views
                        ischannel = True
                    else:
                        views = ''
                    if i:
                        channel_name = i
                    else:
                        channel_name = ''

                    if ischannel:
                        data = {"channel_name": channel_name, "channel_id": channel_id, "message": message,
                                "date": date,
                                "views": views}
                        insert = db.channel_posts.insert_one(data)
                        kafkaproducer({"collections": "channel_posts", "data": data},
                                      topic="telegram_bot")
                        print(data)
                print("all messages fetched...")

            if findc > 0:

                x = db.channel_posts.find({"channel_name":i}).limit(1).sort("$natural", 1)

                for d in x:
                    last_d = d["date"]

                ischannel = False
                messages = client.iter_messages(entity=i, limit=500)
                print("Start fetching new messages of channel %s." % i)
                for k in messages:
                    if k.to_id.channel_id:
                        channel_id = k.to_id.channel_id
                    else:
                        channel_id = ''
                    if k.message:
                        message = k.message
                    else:
                        message = ""

                    if k.date:
                        date = k.date
                    else:
                        date = ''

                    if k.views:
                        views = k.views
                        ischannel = True
                    else:
                        views = ''
                    if i:
                        channel_name = i
                    else:
                        channel_name = ''

                    if ischannel:
                        data_now = {"channel_name": channel_name, "channel_id": channel_id, "message": message,
                                    "date": date,
                                    "views": views}

                        if date.year == last_d.year:

                            if date.month == last_d.month:

                                if date.day == last_d.day:

                                    if date.hour > last_d.hour:
                                        insert = db.channel_posts.insert_one(data_now)
                                        kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                      topic="telegram_bot")

                                else:
                                    if date.day > last_d.day:
                                        insert = db.channel_posts.insert_one(data_now)
                                        kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                      topic="telegram_bot")
                            else:
                                if date.month > last_d.month:
                                    insert = db.channel_posts.insert_one(data_now)
                                    kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                  topic="telegram_bot")
                        else:
                            if date.year > last_d.year:
                                insert = db.channel_posts.insert_one(data_now)
                                kafkaproducer({"collections": "channel_posts", "data": data_now},
                                              topic="telegram_bot")

                print("all new messages fetched...")

    #agar username ya url dashtim
    if username != None:

        g = ''
        if extract_username(username) == "joinchat":
            username = extract_pvgb_username(url=username)
        else:
            username = extract_username(url=username)
        try:
            updates = client(ImportChatInviteRequest(username))
            g = client.get_entity(username)

        except Exception as e:
            print(e)
            g = client.get_entity(username)
            pass

        channel_entity = client.get_entity(g)
        channel_n = channel_entity.title

        findc = db.channel_posts.find({"channel_name": channel_n}).count()

        if findc == 0:
            ischannel = False
            messages = client.iter_messages(entity=channel_entity.title, limit=None)
            print("Start fetching messages of channel %s." % channel_n)
            for k in messages:
                if k.to_id.channel_id:
                    channel_id = k.to_id.channel_id
                else:
                    channel_id = ''
                if k.message:
                    message = k.message
                else:
                    message = ""

                if k.date:
                    date = k.date
                else:
                    date = ''

                if k.views:
                    views = k.views
                    ischannel = True
                else:
                    views = ''
                if channel_n:
                    channel_name = channel_n
                else:
                    channel_name = ''

                if ischannel:
                    data = {"channel_name": channel_name, "channel_id": channel_id, "message": message,
                            "date": date,
                            "views": views}
                    insert = db.channel_posts.insert_one(data)
                    kafkaproducer({"collections": "channel_posts", "data": data},
                                  topic="telegram_bot")
            print("all messages fetched...")

        if findc > 0:

            x = db.channel_posts.find({"channel_name": channel_n}).limit(1).sort("$natural", 1)

            for d in x:
                last_d = d["date"]

            ischannel = False
            messages = client.iter_messages(entity=channel_n, limit=500)
            print("Start fetching new messages of channel %s." % channel_n)
            for k in messages:
                if k.to_id.channel_id:
                    channel_id = k.to_id.channel_id
                else:
                    channel_id = ''
                if k.message:
                    message = k.message
                else:
                    message = ""

                if k.date:
                    date = k.date
                else:
                    date = ''

                if k.views:
                    views = k.views
                    ischannel = True
                else:
                    views = ''
                if channel_n:
                    channel_name = channel_n
                else:
                    channel_name = ''

                if ischannel:
                    data_now = {"channel_name": channel_name, "channel_id": channel_id, "message": message,
                                "date": date,
                                "views": views}

                    if date.year == last_d.year:

                        if date.month == last_d.month:

                            if date.day == last_d.day:

                                if date.hour > last_d.hour:
                                    insert = db.channel_posts.insert_one(data_now)
                                    kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                  topic="telegram_bot")


                            else:
                                if date.day > last_d.day:
                                    insert = db.channel_posts.insert_one(data_now)
                                    kafkaproducer({"collections": "channel_posts", "data": data_now},
                                                  topic="telegram_bot")
                        else:
                            if date.month > last_d.month:
                                insert = db.channel_posts.insert_one(data_now)
                                kafkaproducer({"collections": "channel_posts", "data": data_now},
                                              topic="telegram_bot")
                    else:
                        if date.year > last_d.year:
                            insert = db.channel_posts.insert_one(data_now)
                            kafkaproducer({"collections": "channel_posts", "data": data_now},
                                          topic="telegram_bot")
            print("all new messages fetched...")




#group function
#telegramGroupExtract()
#channel function
#channelExtract()

#==========================join to channel ==============================



def channel_queue(url=None):
    if url != None:
        username = extract_username(url)
        join = client(JoinChannelRequest(username))
        update = db.channel_queue.update({"url": url}, {"$set": {"is_join": True}}, upsert=True,
                                         multi=True)
    else:
        find = db.channel_queue.find({"is_join": False})
        try:
            for i in find:
                username = extract_username(i["url"])
                join = client(JoinChannelRequest(username))
                try:
                    update = db.channel_queue.update({"url": i["url"]}, {"$set": {"is_join": True}}, upsert=False,
                                                     multi=False)
                except:
                    print("somethings wrong - mongodb update")
        except:
            print("somethings wrong - join channel %s." % i)



# https://t.me/joinchat/AAAAAFFszQPyPEZ7wgxLtd
# ===========================join private group==================================

def join_private_group(url=None):
    if url !=None:
        username = extract_pvgb_username(url)
        try:
            updates = client(ImportChatInviteRequest(username))
            update = db.private_gb_queue.update({"url":url}, {"$set": {"is_join": True}}, upsert=True,
                                                multi=True)
        except:
            print("somethings wrong in join pv group")

    else:

        find = db.private_gb_queue.find({"is_join": False})
        for i in find:
            username = extract_pvgb_username(i["url"])

            try:
                join = client(ImportChatInviteRequest(username))
                try:
                    update = db.private_gb_queue.update({"url":i["url"]},{"$set":{"is_join": True}},upsert=False, multi=True)

                except:
                    print("somethings wrong - mongodb update")

            except:
                print("somethings wrong in join pv group %s." % username)
                pass


