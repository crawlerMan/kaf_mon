from pyvirtualdisplay import Display
from selenium import webdriver
display = Display(visible=0, size=(1024, 768))
display.start()
chrom_drive = r"/root/scraper/fb/fb_crw/chromedriver"
browser = webdriver.Chrome(chrom_drive)
browser.get("khabaronline.ir")
po = browser.find_element_by_class_name("tabs-container box").text
for p in po:
	print(p)