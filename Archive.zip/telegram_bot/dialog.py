from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty

from datetime import timedelta
from tkinter import dialog

from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv
import socks

from pymongo import MongoClient
client = MongoClient('localhost')
db = client.telegram


#proxy = (socks.SOCKS5, '127.0.0.1', 9150)


api_id = 796906
api_hash = '80a4ef01149c6c639b815cafbd3aab49'
phone = '+989192683701'
client = TelegramClient(phone, api_id, api_hash)

client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone)
    client.sign_in(phone, input('Enter the code: '))

chats = []



dialogs = []
users = []
chats = []

last_date = None
chunk_size = 20


x = client.get_dialogs()
for i in x:
	message = i.message.message
	t =i.entity
	print(t)
	if t.id:
		user_id = t.id
	else:
		user_id = ""

	if t.username:
		username = t.username
	else:
		username = ""

	print(user_id)
	print(username)
	#print(message)
	print("---")


