from pymongo import MongoClient
client = MongoClient('localhost')
db = client.telegram

def phoneNumberGenerator():
	Irancell = [901, 902, 930, 933, 935, 936, 937, 938, 939]
	MCI = [910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 990, 991, 992]
	Talia = [932]
	Rightel = [920, 921, 922]
	spadan = [931]
	teleKish = [934]
	ApTel = [99910, 99911, 99913]
	AzarTel = [99914]
	SamaTel = [99999, 99998, 99997, 99996]
	Lotustel = [9990]
	shatel = [99810, 99811, 99812]
	Anarestan = [9944]

	precode = {"Irancell": Irancell, "MCI": MCI, "Talia": Talia, "Rightel": Rightel, "spadan": spadan,
	           "teleKish": teleKish, "ApTel": ApTel,
	           "AzarTel": AzarTel, "SamaTel": SamaTel, "Lotustel": Lotustel, "shatel": shatel, "Anarestan": Anarestan}

	counter = 0
	numberList = []
	for key, value in precode.items():
		for i in value:
			counter = 0
			numberList = []
			for j in range(4782969):

				if key in ["Irancell", "MCI", "Talia", "Rightel", "spadan", "teleKish"]:
					phoneNumber = (98000 + i) * 10000000 + j
					numberList.append(phoneNumber)
					counter = counter + 1

					if counter > 20:
						data = {"Operator": key, "phone_number": numberList}
						insert = db.phone_numbers.insert_one(data)
						counter = 0
						numberList = []
						print("data inserted")
						print(data)
						print("--------+++++++++++++++---------")

				if key in ["ApTel", "AzarTel", "SamaTel", "shatel"]:
					phoneNumber = (9800000 + i) * 10000000 + j

					numberList.append(phoneNumber)
					counter = counter + 1

					if counter > 20:
						insert = db.phone_numbers.insert_one(data)
						counter = 0
						numberList = []
						print("data inserted")
						print(data)
						print("--------+++++++++++++++---------")

				if key in ["Anarestan", "Lotustel"]:
					phoneNumber = (980000 + i) * 10000000 + j

					numberList.append(phoneNumber)
					counter = counter + 1

					if counter > 20:
						insert = db.phone_numbers.insert_one(data)
						counter = 0
						numberList = []
						print("data inserted")
						print(data)
						print("--------+++++++++++++++---------")




phoneNumberGenerator()