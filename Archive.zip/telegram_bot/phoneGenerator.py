from datetime import timedelta
from tkinter import dialog
import datetime

from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetParticipantsRequest, GetFullChannelRequest
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputUser, InputUserSelf, ChannelAdminLogEventsFilter, InputChannel, \
    ChannelParticipantsSearch
import csv
import socks

from pymongo import MongoClient
client = MongoClient('localhost')
db = client.telegram


#proxy = (socks.SOCKS5, '127.0.0.1', 9150)


api_id = 796906
api_hash = '80a4ef01149c6c639b815cafbd3aab49'
phone = '+989192683701'
client = TelegramClient(phone, api_id, api_hash)


client.connect()
if not client.is_user_authorized():
    client.send_code_request(phone)
    client.sign_in(phone, input('Enter the code: '))





def entity(phoneNumber):
	number = str(phoneNumber)
	try:
		user = client.get_entity(number)

		try:
			if user.id:
				user_id = user.id
			else:
				user_id = ""

			if user.username:
				username = user.username
			else:
				username = ""

			if user.mutual_contact:
				mutual_contact = user.mutual_contact
			else:
				mutual_contact = ""

			if user.access_hash:
				access_hash = user.access_hash
			else:
				access_hash = ""

			data = {"Phone_number": phoneNumber, "user_id": user_id, "username": username,
			        "mutual_contact": mutual_contact, "access_hash": access_hash}
			print(data)
			try:
				insert = db.telegram_phone_numbers.insert_one(data)
			except:
				print("somethings wrong in mongodb.")

		except:
			print("somthings wrong in fetch data")

	except:
		print("phone number is not in telegram.")
		insert =db.not_telegram_phone_numbers.insert({"Phone_number":phoneNumber})



numbers = [989128439547,989125711305,989128179582]

f = db.phone_numbers.find()

for i in numbers:
	entity(i)
	print(i)
	print("==+++==")



#x = client.get_profile_photos(user)
#print(x)